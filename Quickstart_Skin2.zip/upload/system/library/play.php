<?php
final class Play {
	/**
	* The play module has been removed.
	* This file remains to stop loading errors on old installs
	**/

	public function __construct($registry) {

	}
}
?>
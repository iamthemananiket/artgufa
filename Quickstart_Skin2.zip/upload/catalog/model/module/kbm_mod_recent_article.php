<?php

/**
 * Class ModelModuleKBMModRecentArticle
 */
class ModelModuleKBMModRecentArticle extends Model
{
    public function __construct($registry)
    {
        parent::__construct($registry);
    }
}